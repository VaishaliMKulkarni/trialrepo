package com.tksolution.patternscounter;

import java.util.LinkedHashMap;
import java.util.Map;

public class WordCounter implements IPatternsCounter {
	private static final Integer NMBR = 1;
	@Override
	public Map<String, Integer> getCount(String filecontents, String fileName) {
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String[] contentsArr = PatternsCounterUtils.stringToArray(filecontents);
		if (contentsArr != null) {
			String ky = PatternsCounterUtils.APP_NAME + " " + fileName + " " + NMBR;
			resultMap.put(ky, null);
			for (int i = 0; i < contentsArr.length; i++) {
				if (PatternsCounterUtils.isNumber(contentsArr[i])) {
					continue;
				} else {

					if (resultMap.get(contentsArr[i]) != null) {
						int count = resultMap.get(contentsArr[i]) + 1;
						resultMap.put(contentsArr[i], count);

					} else {
						resultMap.put(contentsArr[i], 1);
					}

				}

			}

		}

		return resultMap;
	}

	}


