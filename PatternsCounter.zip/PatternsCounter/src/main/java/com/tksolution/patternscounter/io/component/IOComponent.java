package com.tksolution.patternscounter.io.component;
import java.util.Map;

import com.tksolution.patternscounter.io.IStdInput;
import com.tksolution.patternscounter.io.IStdOutput;

public class IOComponent {

	IStdInput stdInput;
	IStdOutput stdOutput;

	

	public IOComponent(IStdInput stdInput, IStdOutput stdOutput) {
		if (stdInput == null) {
            throw new IllegalArgumentException("StdInput must not be null.");
        }
		this.stdInput = stdInput;
		
		if (stdOutput == null) {
            throw new IllegalArgumentException("StdOutput must not be null.");
        }
		this.stdOutput = stdOutput;
	}


	public String[] getStdInputs() {
		
			return this.stdInput.getInputs();
		
	}

	
	public void showStdOutput(Map<String, Integer> result) {
		
			this.stdOutput.showOutput(result);
		

	}


}
