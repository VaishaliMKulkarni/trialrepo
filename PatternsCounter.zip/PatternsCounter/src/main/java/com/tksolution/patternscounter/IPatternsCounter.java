package com.tksolution.patternscounter;

import java.util.Map;

public interface IPatternsCounter {
	public Map<String, Integer> getCount(String filecontents, String fileName);

}
