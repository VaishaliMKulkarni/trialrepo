package com.tksolution.patternscounter;

import java.util.Map;

public interface IFilePatternsCounterService {
	Map<String, Integer> getPatternFromFile(String filename, String pattern) throws Exception;

}
