package com.tksolution.patternscounter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class PatternsCounterUtils {
	public static final String APP_NAME = "PatternsCounter";
	
	public static boolean isNumber(String string) {
		return string.chars().allMatch(Character::isDigit);
	}

	public static String[] stringToArray(String str) {
		String[] arr = null;
		if (str == null || str.length() > 0) {
			arr = str.split(" ");
			if (arr.length < 3) {
				arr = null;
			}
		}
		return arr;

	}
	
	public static String[] getContentsFromFile(String filePath) throws Exception {
		if (filePath == null) {
			throw new Exception(" Missing File name");
		} else {
			BufferedReader br = new BufferedReader(new FileReader(filePath));
			try {
				StringBuilder sb = new StringBuilder();

				File file = new File(filePath);
				Scanner scanner = new Scanner(file);

				while (scanner.hasNextLine()) {
					sb.append(scanner.nextLine());
				}
				if (scanner != null) {
					scanner.close();
				}
				String[] result = new String[2];
				result[0] = sb.toString();
				result[1] = file.getName();
				return result;
			} catch (IOException e) {
				throw new Exception("Exception in reading file." + e.getMessage());
			} finally {
				br.close();
			}

		}
	}

	

}
