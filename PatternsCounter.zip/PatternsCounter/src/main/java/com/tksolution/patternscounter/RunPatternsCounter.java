package com.tksolution.patternscounter;

import java.util.Map;

import com.tksolution.patternscounter.io.component.IOComponent;
import com.tksolution.patternscounter.io.impl.StdInputImpl;
import com.tksolution.patternscounter.io.impl.StdOutputImpl;

public class RunPatternsCounter {
	
	private static IFilePatternsCounterService patternsCounterService;

	public static void main(String[] args) {

		/*inject Keyboard and console to IO runner*/
		IOComponent io = new IOComponent(new StdInputImpl(), new StdOutputImpl());
		String inputs[] = io.getStdInputs();
		patternsCounterService = new FilePatternsCounterServiceImpl();
		Map<String, Integer> result = null;

		/*Service call to find and return the distinct pattern*/
		try {
			result = patternsCounterService.getPatternFromFile(inputs[0], inputs[1]);
		} catch (Exception e) {
			System.err.println("Run time exception occured :" + e);
		}

		io.showStdOutput(result);

	}

}
