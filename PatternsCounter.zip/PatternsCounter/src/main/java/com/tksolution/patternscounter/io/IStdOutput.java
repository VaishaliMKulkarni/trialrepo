package com.tksolution.patternscounter.io;

import java.util.Map;

public interface IStdOutput {
	void showOutput(Map<String, Integer> result);

}
