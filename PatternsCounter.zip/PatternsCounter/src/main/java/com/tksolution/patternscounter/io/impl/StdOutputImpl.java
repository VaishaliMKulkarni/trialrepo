package com.tksolution.patternscounter.io.impl;

import java.io.OutputStream;
import java.util.Map;

import com.tksolution.patternscounter.io.IStdOutput;


public class StdOutputImpl implements IStdOutput {
	//private final OutputStream output=System.out;
	
	


	@Override
	public void showOutput(Map<String, Integer> result) {
		// TODO Auto-generated method stub
		for (Map.Entry<String, Integer> entry : result.entrySet()) {
			String key = entry.getKey().toString();
			Integer value = entry.getValue();
			System.out.println(key + ", " + value+"\n");}
		
	}

}
