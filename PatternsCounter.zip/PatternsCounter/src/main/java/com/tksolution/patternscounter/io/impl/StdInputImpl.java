package com.tksolution.patternscounter.io.impl;

import java.io.InputStream;
import java.util.Scanner;

import com.tksolution.patternscounter.io.IStdInput;


public class StdInputImpl  implements IStdInput {

	@Override
	public String[] getInputs() {
		// TODO Auto-generated method stub
		final String[] inputs = new String[2];
        try (final Scanner scanner = new Scanner(System.in)) {
        	System.out.println("Enter data: ");
        	for (int i = 0; i < 2; i++) {
            	
                inputs[i] = scanner.nextLine();
                System.out.println("You entered string " + inputs[i]);
                System.out.println("Enter data: ");
            }
        }
        return inputs;
	}
	
	//private final InputStream input=System.in;

      

}
