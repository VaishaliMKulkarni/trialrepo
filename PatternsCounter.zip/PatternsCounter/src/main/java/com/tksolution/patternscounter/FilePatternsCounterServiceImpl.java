package com.tksolution.patternscounter;

import java.util.Map;

public class FilePatternsCounterServiceImpl implements IFilePatternsCounterService {
	PatternsCounterFactory patternsCounterFactory = new PatternsCounterFactory();
	IPatternsCounter patternsCounter;
	
	@Override
	public Map<String, Integer> getPatternFromFile(String filename, String  pattern) throws Exception {
		Map<String, Integer> patterncount = null;
		if (filename == null || pattern == null) {
			return patterncount;
		} else {
			patternsCounter = patternsCounterFactory.getPatternsCounter(Pattern.of(pattern));
		}
		String[] values = PatternsCounterUtils.getContentsFromFile(filename);
		if (patternsCounter != null) {
			patterncount = patternsCounter.getCount(values[0], values[1]);
		} else {
			throw new Exception("Pattern is null or invalid");
		}

		return patterncount;
	}
	}


