package com.tksolution.patternscounter;

import java.util.LinkedHashMap;
import java.util.Map;

public class PhraseCounter implements IPatternsCounter {

	private static final Integer NMBR = 3;
	@Override
	public Map<String, Integer> getCount(String filecontents, String fileName) {
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String[] contentsArr = PatternsCounterUtils.stringToArray(filecontents);
		if (contentsArr != null) {
			String ky = PatternsCounterUtils.APP_NAME + " " + fileName + " " + NMBR;
			resultMap.put(ky, null);
			for (int i = 0; i < contentsArr.length - 2; i++) {
				if (isPhrase(contentsArr, i)) {
					String tmp = getPhraseKey(contentsArr, i);
					if (resultMap.get(tmp) != null) {
						int count = resultMap.get(tmp) + 1;
						resultMap.put(tmp, count);
					} else {
						resultMap.put(tmp, 1);
					}
				}

			}

		}

		return resultMap;
	}
	
	
	private String getPhraseKey(String[] contentsArr, int i) {
		return contentsArr[i] + " " + contentsArr[i + 1] + " " + contentsArr[i + 2];
	}

	private boolean isPhrase(String[] contentsArr, int start) {
		return (contentsArr.length >= start + 2);
	}

}
