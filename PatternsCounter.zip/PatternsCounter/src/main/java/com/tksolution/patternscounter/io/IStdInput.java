/**
 * 
 */
package com.tksolution.patternscounter.io;


public interface IStdInput {
	
	String[] getInputs();

}
