package com.tksolution.patternscounter;

import java.util.Objects;

public enum Pattern {
	WORD("1"),
    NUMBER("2"),
    PHRASE("3");

    private final String value;

    Pattern(final String value) {
        this.value = value;
    }

    public static Pattern of(final String type) {
        for (final Pattern pattern : values()) {
            if (Objects.equals(pattern.value, type)) {
                return pattern;
            }
        }
        return null;
      //  throw new IllegalArgumentException();
    }

}
