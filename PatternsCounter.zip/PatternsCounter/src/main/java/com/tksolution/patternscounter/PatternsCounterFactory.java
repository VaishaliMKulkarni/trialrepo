package com.tksolution.patternscounter;

public class PatternsCounterFactory {
	public IPatternsCounter getPatternsCounter(Pattern type) throws NullPointerException {
		//IPatternsCounter patternsCounter = null;
if (type == null) {
        return null;   // throw new NullPointerException("Pattern must not be null, it can be 1/2/3");
        }
		switch (type) {
        case WORD: return new WordCounter();
        case NUMBER: return new NumberCounter();
        case PHRASE: return new PhraseCounter();
    }
		return null;

}
}