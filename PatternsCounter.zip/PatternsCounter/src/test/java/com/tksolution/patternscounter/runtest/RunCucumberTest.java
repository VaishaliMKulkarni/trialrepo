package com.tksolution.patternscounter.runtest;


import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;


@RunWith(Cucumber.class)
@CucumberOptions(glue = { "com.tksolution.patternscounter" }, features = { "src/test/resources/feature" }, plugin = {"pretty", "html:target/cucumber-report.html"} )

public class RunCucumberTest {

}
